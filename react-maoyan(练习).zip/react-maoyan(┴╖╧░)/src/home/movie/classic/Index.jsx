import React, { Component } from 'react';

class Index extends Component {
  
  render() {
    return (
      <div>classic</div>
    );
  }
}

export default Index;