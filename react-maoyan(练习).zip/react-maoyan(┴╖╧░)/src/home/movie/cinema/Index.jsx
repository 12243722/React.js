import React, { Component } from 'react';

class Index extends Component {
  
  render() {
    return (
      <div>cinema</div>
    );
  }
}

export default Index;