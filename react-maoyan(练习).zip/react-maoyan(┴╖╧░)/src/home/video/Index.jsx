import React, { Component } from 'react';

class Index extends Component {
  
  render() {
    return (
      <div>video</div>
    );
  }
}

export default Index;