import React, { Component } from 'react';

class Index extends Component {
  
  render() {
    return (
      <div>mine</div>
    );
  }
}

export default Index;