import React, { Component } from 'react';
// import { Button } from 'antd-mobile';

import Home from './home/Index';


class App extends Component {

  render() {
    return (
      <div>
        <Home />
      </div>
    );
  }
}

export default App;