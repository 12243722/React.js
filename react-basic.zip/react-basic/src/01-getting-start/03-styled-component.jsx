import React, { Component } from 'react';

import { DivStyled } from './03-styled.jsx';


class App extends Component {
  render() {
    return (
      <DivStyled primary="100px">
        app3
      </DivStyled>
    );
  }
}

export default App;