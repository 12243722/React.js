import React from 'react';

const Child2 = (props) => {
  return (
    <div>Child2-{props.num}</div>
  );
}

export default Child2;