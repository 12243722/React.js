const GET_DATA = '/api/list';

export { GET_DATA };