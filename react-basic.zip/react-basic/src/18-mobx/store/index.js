import count from './count'

// 定义store
const store = {
  count
};

export default store;