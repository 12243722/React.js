import React from 'react';

const Home = (props) => {
  return (
    <div>{props.children}Home</div>
  );
}

export default Home;