import React from 'react';

const Bb = () => {
  return (
    <div>Bb</div>
  );
}

export default Bb;