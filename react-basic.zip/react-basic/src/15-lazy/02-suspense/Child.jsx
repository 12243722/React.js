import React from 'react';

console.log(123)

const Child = () => {
  return (
    <div>child</div>
  );
}

export default Child;