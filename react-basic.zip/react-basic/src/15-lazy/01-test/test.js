function test(){
  document.getElementById('root')
  root.innerHTML='页面变的有内容了'
}
export {test}